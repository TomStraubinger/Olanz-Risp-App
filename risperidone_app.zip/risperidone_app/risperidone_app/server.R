##Risp

#Load Libraries
library(ggplot2)
library(plyr)
library(reshape2)
library(grid)
library(dplyr)
library(magrittr)
library(tidyr)
library(DT)
library(mrgsolve)
library(minqa)
library(plotly)


## GGplot Options
theme_set(theme_bw())
theme_update(
  axis.title.x = element_text(face="bold", size=20, margin=margin(20,0,0,0)),
  axis.title.y = element_text(face="bold",angle=90, size=20, margin=margin(0,20,0,0)),
  axis.text.x = element_text(size=15),
  axis.text.y = element_text(size=15),
  legend.direction="vertical",
  legend.position="right",
  legend.key = element_blank(),
  legend.key.height=unit(3,"line"),
  legend.text =  element_text(size=14),
  legend.title = element_text(size=15,vjust=1),
  plot.title = element_text(face="bold",size=26, vjust = 1.6)
 
)

#Read in model > 
setwd("C:/Users/tas10/Box/Bies Lab/olanz_ris/Olanz-Risp App 10-2-2020/risperidone_app/risperidone_app")
mod<-mread("risp")


# Define functions --------------------------------------------------------


# Defining MAP Bayes function ---------------------------------------------
mapBayesObj <- function (eta, omega,sigma,data,model){
  eta <- as.list(eta)
  eta_m <- unlist(eta) %>% matrix (nrow = 1)
  mod <- param(mod, eta)
  obs <- filter(data, EVID == 0)
  obs_time <-  dplyr::select(obs,TIME)
  dosing <- filter (data, EVID==1)
  omega.inv = solve(omega)
  sim <- mod %>%
    zero_re()%>%
    obsonly()%>%
    data_set(dosing)%>%
    mrgsim (end = -1, add = unlist(obs_time))%>%as.data.frame()
  
  predictions <- gather (sim,CMT,PRED,Cp,Cm)%>% mutate (CMT = ifelse(CMT=="Cp",2,3))%>%
    dplyr::select(ID,TIME,CMT,PRED)
  
  predictionsAndObserved <- merge (predictions,obs, by = c("ID","TIME","CMT"))%>% filter(!is.na(DV))%>%
    mutate(
      varj = var(CMT,PRED,sigma[1],sigma[2],sigma[3],sigma[4]),
      log_varj = log(varj),
      sqwres = 1/varj*(DV-PRED)^2)
  
  nOn <- as.numeric(eta_m %*% omega.inv %*% t(eta_m))
  return(sum(predictionsAndObserved$sqwres) +sum(predictionsAndObserved$log_varj)+ nOn)
}


var <- function (CMT,PRED,sigma1,sigma2,sigma3,sigma4){
  ifelse(CMT==2, sigma1*PRED+sigma2,sigma3*PRED+sigma4)
} 


mod1 <- mod %>% param(EM_T=0,IM_T=0, PM_T=1)
mod2 <- mod %>% param(EM_T=0,IM_T=1, PM_T=0)
mod3 <- mod %>% param(EM_T=1,IM_T=0, PM_T=0)
mods <-list(mod1,mod2,mod3)



shinyServer(
  
  function(input, output) {
    ##### Initial (Population) Dosing############    
    output1 <- reactive({
      
    ### Covariates
    AGE <- input$AGE
    
    ### POP Parameters
    V <- 444
    KA <- 1.7
    CL <- 12.9 ##Poor metabolizer
    ke <- CL/V
  
    # Input number of doses & interval
    n=input$n
    interval= input$interval 
    
    # Input PD Parameters
    Emax = .88
    EC50 = 8.2
    
    # User inputs trough if they would like to target a specific trough
    # Cmin <- if (input$par_est == "Trough (SS)") input$trough else
    #         if (input$par_est == "Receptor Occupancy at Trough (SS)") input$r_occ/100*EC50/Emax/(1-input$r_occ/100/Emax)
    # 
    # 
    # if user would like to simulate for specific dose, input dose
    # if user would like to target specific trough, dose is calculated
    dose <- if(input$par_est== "Dose"  ) input$dose #else
      # if (input$par_est == "Trough (SS)" ) Cmin * V * (KA * exp(-ke * interval) * exp(-KA * interval) - exp(-ke * interval) * exp(-KA * interval) * ke - KA * exp(-ke * interval) - KA * exp(-KA * interval) + ke * exp(-ke * interval) + exp(-KA * interval) * ke + KA - ke) / KA / (exp(-ke * interval) - exp(-KA * interval)) else
      # if (input$par_est == "Receptor Occupancy at Trough (SS)" && input$data ==FALSE) 1/1000*Cmin * V * (KA * exp(-ke * interval) * exp(-KA * interval) - exp(-ke * interval) * exp(-KA * interval) * ke - KA * exp(-ke * interval) - KA * exp(-KA * interval) + ke * exp(-ke * interval) + exp(-KA * interval) * ke + KA - ke) / KA / (exp(-ke * interval) - exp(-KA * interval))
      # 
      # 
    # Simulate for steady state?
    SS= input$SS

    # simulating PK profile  ## Default is poor metabolizer
    out <- mod %>%
      param(AGE= AGE)%>%
       ev(cmt = 1,amt = dose, ii=interval,ss=as.numeric(SS), addl = n-1)%>% 
      mrgsim(end=interval*(n+5), delta = .5)
    conc <- as.data.frame(out)%>% dplyr::rename(conc = Cp, TIME =time)

    # PD Response
    conc$occupancy<- (Emax*conc$Ctot)/(EC50+conc$Ctot)
    
    df<-data.frame()
    df<-datatable(df,options=list(paging=FALSE,searching=FALSE,ordering=FALSE,columns.width=2))
    
    legend<-  NA
    legend2<- 1
    
    plot1<-ggplot(conc, aes(x=TIME, y=conc))+
      geom_line(size=1)+ylim(0,max(conc$Ctot)+20)+
      geom_line(aes(y=Ctot),size=1)+
      geom_line(aes(y=Cm),size=1)+
      labs(x="Time (hr)", y="Concentration (ug/L)")+
      xlim(0,(n+5)*interval)+
      guides(color=guide_legend(override.aes=list(shape=legend,linetype=legend2)))
    
    plot3<-ggplot(conc, aes(x=TIME, y=occupancy*100))+
      geom_line(size=1)+ylim(0,100)+
      labs(x="Time (hr)", y="Receptor Occupancy (%)")+
     xlim(0,(n+2)*interval)
      
    output<-list(plot1,df,plot3)

    })
    
    output$plot1 <- renderPlot (height = 500, units="px",{
    list<-output1()
    list[[1]]
      }
    )
    
    output$plot3 <- renderPlot (height = 500, units="px",{
      list<-output1()
      list[[3]]
    }
    )
    
    output$table1 <- renderDataTable({
      list <- output1()
      list[[2]]
    })
    
######Adaptive Dosing##########
    output2 <- reactive ( {
      dose <- input$dose2 
      AGE <- input$AGE2

      omega1 <- cmat(0.35,0,.3 ,0,0,0.54)
      omega2 <- cmat(0.27,0,.3 ,0,0,0.54)
      omega3 <- cmat(0.39,0,.3 ,0,0,0.54)
      omegas <- list(omega1,omega2,omega3)
      sigma_slope1 <-.639 #risp
      sigma_add1 <- 4.29 #risp
      
      sigma_slope2 <-.379 #9OH
      sigma_add2 <- 0.88
      
      sigma <- c(sigma_slope1,sigma_add1,sigma_slope2,sigma_add2)
      
      interval = input$intervaladapt
      SS=ifelse(input$SS_adapt=="Steady State",1,0)
      
      data = data.frame(ID=1, TIME = 0, AMT = dose,  SS=SS, II= interval, MDV = 1, DV = NA, CMT =1,AGE = AGE, EVID=1)
      initial <- c(ETA1=.1, ETA2=.1, ETA3 = .1)

      
      
      if (input$n_obs=="1") { 
      t<- input$timeafterdose
      Conc_measured <- input$Concentration
      Conc_measured_m <-input$Concentration_m
      Conc <-c(Conc_measured,Conc_measured_m)
      obs_data = data.frame (ID=1, TIME=t, AMT=NA, SS =0, II = NA, MDV = 0, DV = Conc, CMT= c(2,3),AGE=AGE,EVID=0)
      }
        
      if (input$n_obs=="2"){
       time1 <- input$timeafterdose
       time2 <- input$timeafterdose2
       conc1 <- input$Concentration
       Conc_measured_m <-input$Concentration_m
       conc2 <- input$Concentration2
       Conc_measured_m2 <-input$Concentration_m2
       

       t=c(time1,time1,time2,time2)
       Conc=c(conc1,Conc_measured_m,conc2,Conc_measured_m2)
       
       obs_data = data.frame (ID=1, TIME=t, AMT=NA, SS =0, II = NA, MDV = 0, DV = Conc, CMT= c(2,3),AGE=AGE,EVID=0)
      }
      
      data_all <- rbind(data,obs_data)
      
      # # Defining MAP Bayes function ---------------------------------------------
      mapBayesObj <- function (eta, omega,sigma,data,model){
        eta <- as.list(eta)
        eta_m <- unlist(eta) %>% matrix (nrow = 1)
        mod <- param(mod, eta)
        obs <- filter(data, EVID == 0)
        obs_time <-  dplyr::select(obs,TIME)
        dosing <- filter (data, EVID==1)
        omega.inv = solve(omega)
        sim <- mod %>%
          zero_re()%>%
          obsonly()%>%
          data_set(dosing)%>%
          mrgsim (end = -1, add = unlist(obs_time))%>%as.data.frame()

        predictions <- gather (sim,CMT,PRED,Cp,Cm)%>% mutate (CMT = ifelse(CMT=="Cp",2,3))%>%
          dplyr::select(ID,TIME,CMT,PRED)

        predictionsAndObserved <- merge (predictions,obs, by = c("ID","TIME","CMT"))%>% filter(!is.na(DV))%>%
          mutate(
            varj = var(CMT,PRED,sigma[1],sigma[2],sigma[3],sigma[4]),
            log_varj = log(varj),
            sqwres = 1/varj*(DV-PRED)^2)

        nOn <- as.numeric(eta_m %*% omega.inv %*% t(eta_m))
        return(sum(predictionsAndObserved$sqwres) +sum(predictionsAndObserved$log_varj)+ nOn)
      }


      var <- function (CMT,PRED,sigma1,sigma2,sigma3,sigma4){
        ifelse(CMT==2, sigma1*PRED+sigma2,sigma3*PRED+sigma4)
      }
      
      
      
      obj=999999
      for (j in 1:3){
        mod<- mods[[j]]
        omega <- omegas[[j]]
        fit<-newuoa(initial,mapBayesObj,omega=omega,sigma=sigma,data=data_all,model=mod)
        objnew = fit$fval
        print(j)
        if (objnew < obj) {
          fitfinal <- fit
          obj<-objnew
          modfin <- j}
      }
      mod <- mods[[modfin]]

      SS<- as.numeric(input$SS2)

      n=input$n2
      interval2= input$interval2  #hr
      interval = input$intervaladapt
      Emax = 1
      EC50 = 8.7

       dose2<-input$doseadapt
       SS<- as.numeric(input$SS2)
       print(fitfinal$par)

       out <- mod %>%
         param(ETA1=fitfinal$par[1],
               ETA2=fitfinal$par[2],
               ETA3=fitfinal$par[3],
               AGE=AGE)%>%
         data_set(expand.ev(ID=1,cmt = 1,amt = c(dose,dose2), ii=c(interval,interval2),ss=as.numeric(SS), addl = n-1)[c(1,4),])%>%
         mrgsim(end=interval*n, delta = .5)
       conc <- as.data.frame(out)%>% dplyr::rename(conc = Cp, TIME =time)

       outpopmean <- mod %>%
         param(AGE=AGE,
               ETA1=0,
               ETA2=0,
               ETA3=0)%>%
         data_set(expand.ev(ID=1,cmt = 1,amt = c(dose,dose2), ii=c(interval,interval2),ss=as.numeric(SS), addl = n-1)[c(1,4),])%>%
         mrgsim(end=interval*n, delta = .5)
       concpopmean <- as.data.frame(outpopmean)%>% dplyr::rename(conc = Cp, TIME =time)

       conc$occupancy<- (Emax*conc$conc)/(EC50+conc$conc)

       KA <- conc$KA[1]
       K20 <- conc$KE[1]
       V <- conc$V[1]
       CL <- conc$CL[1]
       ke <-K20



      conc2<- filter(conc, ID==4)
      conc <- filter(conc, ID==1)

      conc$X.ID<-"Original Dose"
      conc2$X.ID<-"Adjusted Dose"

      conc2popmean<- filter(concpopmean, ID==4)
      concpopmean <- filter(concpopmean, ID==1)
      concpopmean$X.ID<-"Original Dose"
      conc2popmean$X.ID<-"Adjusted Dose"


      #observed
      boogity <- data.frame(t=t, Conc=Conc)

      

      

      p<-ggplot(conc, aes(x=TIME, y=conc, color=X.ID))+geom_line(size=.7)+geom_line(size=.7,aes(y=Cm))+ylim(0,75)+
        labs(x="Time (hr)", y="Concentration (ug/L)",color='')+geom_line(data=conc2,size=.7)+
        geom_line(data=conc2popmean,size=.7,linetype=2)+geom_line(data=concpopmean,size=.7,linetype=2)+
        geom_point(data=boogity,aes(x=t, y=Conc, color="Observed Concentration"),size=2)+
        guides(color=guide_legend(override.aes=list(shape=c(NA,16,NA),linetype=c(1,0,1))))+
        scale_colour_manual(values = c(3,2,4))

      plot4<-ggplot(conc, aes(x=TIME, y=occupancy*100, color=X.ID))+
        geom_line(size=.7)+ylim(0,100)+geom_line(data=conc2,size=.7)+
        labs(x="Time (hr)", y="Receptor Occupancy (%)")+
        xlim(0,(n+2)*interval)+
        scale_colour_manual(values = c(3,4))

      # newdose<-dose2
      # 
      # CminSS <-1000*dose*KA*(exp(-ke*interval)/(1-exp(-ke*interval))-exp(-KA*interval)/(1-exp(-KA*interval)))/V/(KA-ke)
      # occupancyminSS<- (Emax*CminSS)/(EC50+CminSS)*100
      # 
      # tmaxSS <- log(KA/ke*(1-exp(-ke*interval))/(1-exp(-KA*interval)))/(KA-ke)
      # CmaxSS <- 1000*dose*KA*(exp(-ke*tmaxSS)/(1-exp(-ke*interval))-exp(-KA*tmaxSS)/(1-exp(-KA*interval)))/V/(KA-ke)
      # 
      # CminSSadapt <-1000*newdose*KA*(exp(-ke*interval2)/(1-exp(-ke*interval2))-exp(-KA*interval2)/(1-exp(-KA*interval2)))/V/(KA-ke)
      # occupancyminSSadapt<- (Emax*CminSSadapt)/(EC50+CminSSadapt)*100
      # 
      # 
      # Parameter <- c('Dose (mg)', "CL (L/hr)", "Vd (L)", "Trough (SS) (mcg/L)","Receptor Occupancy at SS Trough (%)", 'ka (1/hr)', 'ke (1/hr)')
      # Value <- c(dose, CL, V, CminSS,occupancyminSS, KA, ke)
      # Value2<-c(newdose, CL, V, CminSSadapt,occupancyminSSadapt, KA, ke)
      # df<-data.frame(Parameter, "Original Dose"=round(Value,digits=2),"New Dose"=round(Value2,digits=2))
      # 
      # df<-datatable(df,options=list(paging=FALSE,searching=FALSE,ordering=FALSE,columns.width=2))
      df<-NULL
      
      plot4=NULL
      list<- list(p,df, plot4)
     
        
    })
    
    output$plot2 <- renderPlot ( height = 500, units="px",{
    list<-output2()
    list[[1]]
    })
    
    output$plot4 <- renderPlot (height = 500, units="px",{
      list<-output2()
      list[[3]]
    }
    )
    
    
    
    output$table2 <- renderDataTable({
      
      list<-output2()
      list[[2]]
      

    })
    
})
