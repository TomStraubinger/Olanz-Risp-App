library(DT)
library(plotly)

shinyUI(
  
  navbarPage("Risperidone PK Simulation",position = "fixed-top",
             
             tabPanel("Initial Dosing", 
                      fluidPage(
                        theme = "bootstrap.css",
                        tags$style(type="text/css", "body {padding-top: 60px; padding-left:40px;}"),
                        column(3,
                               wellPanel(
                                 h4("Covariates"),
                                 hr(),
                                 numericInput('AGE', 'Age', value = 50)
                               ),
                               wellPanel(
                                 h4("Dosing"),
                                 hr(),
                                   selectInput ("par_est",
                                                label = NULL,
                                                choices= c("Dose"
                                                           # "Trough (SS)",
                                                           # "Receptor Occupancy at Trough (SS)"
                                                ),
                                                selected = "Dose"),
                                   conditionalPanel(
                                     condition="input.par_est == 'Dose'" ,
                                     numericInput("dose",
                                                  label = "Dose (mcg)",
                                                  value= 2000)
                                   ),
                                   conditionalPanel(
                                     condition="input.par_est == 'Trough (SS)'",
                                     numericInput("trough",
                                                  label = "Trough (ug/L)",
                                                  value= 26)
                                   ),
                                   conditionalPanel(
                                     condition="input.par_est ==  'Receptor Occupancy at Trough (SS)'",
                                     numericInput("r_occ",
                                                  label = "Receptor Occupancy (%)",
                                                  value= 80)
                                   ),
                                   numericInput ('interval', 'Enter dosing interval in hours', value = 24),
                                   numericInput('n', 'Enter Number of Doses', value= 5)
                                 ),
                                   checkboxInput('SS', 'View Steady State Profile', value = FALSE)
                               
                        ),
                        
                        column(9,
                               column(12,
                                      tabsetPanel(type="tabs",
                                                  tabPanel("PK Profile", plotOutput("plot1",height="auto")),
                                                  tabPanel("Receptor Occupancy",plotOutput("plot3",height="auto")),
                                                  tabPanel ("Parameters",column(4,dataTableOutput('table1')))
                                      )
                               )
                        )
                      )
             ),
             tabPanel("Adaptive Dosing", 
                      fluidPage(
                        titlePanel("Risperidone PK Simulation"),
                        column(4,
                               wellPanel(
                                   tabsetPanel(type="tabs",
                                               tabPanel("Observed",
                                                        numericInput("AGE2","Age",value=50), 
                                                        radioButtons("SS_adapt",
                                                                     label = "Concentration/s taken at:",
                                                                     choices= c("Single Dose", "Steady State"),
                                                                     inline=T),   
                                                        radioButtons("n_obs",
                                                                     label = "Number of observations:",
                                                                     choices= c("1", "2"),
                                                                     inline=T), 
                                                        numericInput("dose2",
                                                                     label = "Dose Adminstered (mcg)",
                                                                     value= 2000),
                                                        conditionalPanel(
                                                          condition="input.SS_adapt == 'Steady State' ",
                                                          numericInput("intervaladapt",
                                                                       label = "Dosing Interval (hrs.)",
                                                                       value= 24)),
                                                        h4("Observation 1",align="center", style = "color:red"),
                                                        fluidRow(column(4, 
                                                                        numericInput("timeafterdose",
                                                                                     label = "Enter time after dose (hrs)",
                                                                                     value= 12)),
                                                                 column(4,
                                                                        numericInput("Concentration",
                                                                                     label = "Enter observed concentration (mcg/L)",
                                                                                     value= 10)),
                                                                 column(4,
                                                                        numericInput("Concentration_m",
                                                                                     label = "Enter observed 9-OH concentration (mcg/L)",
                                                                                     value= 10))),
                                                        fluidRow(conditionalPanel(
                                                          condition="input.n_obs == '2' ",
                                                          h4("Observation 2",align="center", style = "color:red"), 
                                                          column(4, 
                                                                 numericInput("timeafterdose2",
                                                                              label = "Enter time after dose (hrs)",
                                                                              value= 10)), 
                                                          column(4,
                                                                 numericInput("Concentration2",
                                                                              label = "Enter observed concentration (mcg/L)",
                                                                              value= 12)),
                                                          column(4,
                                                                 numericInput("Concentration_m2",
                                                                              label = "Enter observed 9-OH concentration (mcg/L)",
                                                                              value= 10))))
                                                        
                                               ),
                                               tabPanel("Simulate New Regimen",
                                                        numericInput ('interval2', 'Enter dosing interval in hours', value = 24),
                                                        numericInput('n2', 'Enter Number of Doses', value= 5),
                                                        selectInput ("par_est1",
                                                                     label = "",
                                                                     choices= c("Dose"
                                                                                # "Trough (SS)",
                                                                                # "Receptor Occupancy at Trough (SS)"
                                                                     ),
                                                                     selected = "Dose"),
                                                        conditionalPanel(
                                                          condition="input.par_est1 == 'Dose' ",
                                                          numericInput("doseadapt",
                                                                       label = "Dose (mcg)",
                                                                       value= 50)),
                                                        conditionalPanel(
                                                          condition="input.par_est1 == 'Trough (SS)' ",
                                                          numericInput("troughadapt",
                                                                       label = "Trough (ug/L)",
                                                                       value= 26)),
                                                        conditionalPanel(
                                                          condition="input.par_est1 ==  'Receptor Occupancy at Trough (SS)' & input.data== false ",
                                                          numericInput("r_occ1",
                                                                       label = "Receptor Occupancy (%)",
                                                                       value= 80)))),
                                   checkboxInput('SS2', 'View Steady State Profile', value = FALSE))),
                        column(8,
                               column(12, tabsetPanel(type = "tabs",
                                                      tabPanel("PK Profile",plotOutput("plot2", height="auto")),
                                                      tabPanel("Receptor Occupancy", plotOutput("plot4", height="auto") ),
                                                      tabPanel("Parameters",column(4,dataTableOutput('table2')))
                               )
                               )
                               
                               
                        )
                      )
             )
  )
)