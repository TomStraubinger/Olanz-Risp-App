library(ggplot2)
library(mrgsolve)
library(minqa)
library(dplyr)
library(magrittr)
library(reshape2)
library(tidyr)

# Setting working directory -----------------------------------------------

if(Sys.info()['sysname']=="Linux"){
  setwd("/media/mhismail/TI10657300D/Users/Mohamed/Desktop/Rprogramming/RispSim_v2")
}else{
  setwd("C:/Users/Mohamed/Desktop/Rprogramming/RispSim_v2")
}

# Setting theme of plots --------------------------------------------------

theme_set(theme_bw())
theme_update(legend.position = "bottom",
             plot.title = element_text(hjust = 0.5))


# Defining MAP Bayes function ---------------------------------------------
mapBayesObj <- function (eta, omega,sigma,data,model){
  eta <- as.list(eta)
  eta_m <- unlist(eta) %>% matrix (nrow = 1)
  mod <- param(mod, eta)
  obs <- filter(data, EVID == 0)
  obs_time <-  select(obs,TIME)
  dosing <- filter (data, EVID==1)
  omega_inv = solve(omega)
  sim <- mod %>%
    drop.re()%>%
    obsonly()%>%
    data_set(dosing)%>%
    mrgsim (end = -1, add = unlist(obs_time))%>%as.data.frame()
  
  predictions <- gather (sim,CMT,PRED,Cp,Cm)%>% mutate (CMT = ifelse(CMT=="Cp",2,3))%>%
    select(ID,TIME,CMT,PRED)
  
  predictionsAndObserved <- merge (predictions,obs, by = c("ID","TIME","CMT"))%>% filter(!is.na(DV))%>%
    mutate(
      varj = var(CMT,PRED,sigma[1],sigma[2],sigma[3],sigma[4]),
      log_varj = log(varj),
      sqwres = 1/varj*(DV-PRED)^2)
  
  nOn <- as.numeric(eta_m %*% omega_inv %*% t(eta_m))
  return(sum(predictionsAndObserved$sqwres) +sum(predictionsAndObserved$log_varj)+ nOn)
}


var <- function (CMT,PRED,sigma1,sigma2,sigma3,sigma4){
  ifelse(CMT==2, sigma1*PRED+sigma2,sigma3*PRED+sigma4)
} 


# Model Settings ----------------------------------------------------------

# omega1 <- cmat(0.426,0,1.68 ,0,0,0.427)
# omega2 <- cmat(0.5,0,1.68 ,0,0,0.427)
# omega3 <- cmat(0.0078,0,1.68 ,0,0,0.427) 
omega1 <- cmat(0.35,0,.3 ,0,0,0.54)
omega2 <- cmat(0.27,0,.3 ,0,0,0.54)
omega3 <- cmat(0.39,0,.3 ,0,0,0.54)
omegas <- list(omega1,omega2,omega3)
sigma_slope1 <-.639
sigma_add1 <- 4.29

sigma_slope2 <-.379
sigma_add2 <- 0.88

sigma <- c(sigma_slope1,sigma_add1,sigma_slope2,sigma_add2)



# omegas <- list(omega1,omega2,omega3)
# sigma_slope1 <- exp(.0064) 
# sigma_add1 <- 0.00013 
# 
# sigma_slope2 <-exp(.0047)
# sigma_add2 <- 0.005 

mod <- mread ("risp")

initial <- c(ETA1=.1, ETA2=.1, ETA3 = .1)


mod1 <- mod %>% param(EM_T=0,IM_T=0, PM_T=1)
mod2 <- mod %>% param(EM_T=0,IM_T=1, PM_T=0)
mod3 <- mod %>% param(EM_T=1,IM_T=0, PM_T=0)



# Read in raw data --------------------------------------------------------


raw <- read.csv("PPK_RIS_raw.csv",as.is=T)
raw$AMT <- as.numeric(raw$AMT)
raw1<-raw
raw1<-mutate(raw1, AMT=as.numeric(AMT),II=as.numeric(II),DV=as.numeric(DV))
raw1$SS <- as.numeric(raw1$SS)


raw1<- select (raw1, ID:AGE)#%>% filter(ID != 8)
raw1$EVID= ifelse(raw1$MDV==0,0,1) 

data1<- read.csv("raw_ris.csv",as.is = T)
data2<- merge(data1,pred)
ris <-data1


i=1

#[1]  1  3  4  6  7  8  9 10 15 21 45 46
pred <- NULL #initialize empty dataset
for (i in 1:length(unique(raw1$ID))){
  IDi=as.numeric(unique(raw1$ID)[i])
  
  ID_i_data <- filter(raw1,ID==IDi)
  obstime <- ID_i_data$TIME[length(ID_i_data$TIME)]
  
  risi = filter(ris,ID==IDi)
  
  
  
  data = ID_i_data
  # y=arrange(ID_i_data,ID,CMT)%>%filter(.,!is.na(DV))
  # y=y$DV
  # time = ID_i_data$TIME[!is.na(ID_i_data$DV)]
  # 
  
  mods <-list(mod1,mod2,mod3)
  obj=999999
  for (j in 1:3){
    mod<- mods[[j]]
    omega <- omegas[[j]]
    fit<-newuoa(initial,mapBayesObj,omega=omega,sigma=sigma,data=data,model=mod)
    objnew = fit$fval
    print (fit$fval)
    if (objnew < obj) {
      fitfinal <- fit
      obj<-objnew
      modfin <- j}
  }
  fitfinal
  modfin
  
  fitfinal$par
  mod<- mods[[modfin]]
  last = obstime[length(obstime)]
  out <- mod %>%
    param(list(ETA1=fitfinal$par[1],ETA2=fitfinal$par[2],ETA3=fitfinal$par[3]))%>%
    zero.re()%>%
    data_set(filter(data,EVID==1)) %>% 
    mrgsim(end=-1,delta=1,add=unlist(last))
  conc <- as.data.frame(out)%>% rename (conc = Cp)
  
  pred <- rbind(pred, data.frame(ID=IDi,ris=conc$conc[conc$TIME==last],
                                 OH=conc$Cm[conc$TIME==last],
                                 tot=conc$Ctot[conc$TIME==last],
                                 dist=modfin,
                                 pred_occ=conc$occ[conc$TIME==last],
                                 CL=conc$CL[conc$TIME==last],
                                 CLM=conc$CLM[conc$TIME==last],
                                 V=conc$V[conc$TIME==last]))
  
  risi$TIME = last
  out <- mod %>%
    param(list(ETA1=fitfinal$par[1],ETA2=fitfinal$par[2],ETA3=fitfinal$par[3]))%>%
    zero.re()%>%
    data_set(filter(data,EVID==1)) %>% 
    mrgsim(end=obstime[length(obstime)]+10,delta=1,add=unlist(obstime))
  conc <- as.data.frame(out)%>% rename (conc = Cp)
  print(ggplot(filter(conc,conc!=0), aes(x =TIME, y= conc,color="IPRED" ))+geom_line()+geom_line(aes(y=Cm),color="green")+
          geom_point(data=filter(data,EVID==0),aes(x=TIME,y=DV,color=as.factor(CMT)))+
          geom_point(data=risi,aes(x=TIME,y=obs_RIS))+geom_point(data=risi,aes(x=TIME,y=obs_OH))+
          labs(title=IDi))
  
  
}

# Compare to NONMEM and raw data ------------------------------------------

theme_set(theme_bw())
theme_update(legend.position = "bottom",
             plot.title = element_text(hjust = 0.5))




data1<- read.csv("raw_ris.csv",as.is = T)
data2<- merge(data1,pred)
ris <-data1

a=ggplot(data2,aes(x=pred_tot_NM,y=obs_tot))+geom_point(aes(color="NONMEM Predicted"),size=2)+
  geom_abline(slope=1,intercept = 0)+scale_y_continuous(limits=c(0,72))+scale_x_continuous(limits=c(0,72))+
  geom_point(aes(x=tot,color="App Predicted"),size=2)+geom_text(aes(label=ID),nudge_y=2)+
  labs(colour=NULL,title="Risperidone + OH", y = "Observed Risperidone + OH (mcg/L)", x="Predicted Risperidone + OH (mcg/L)")
print(a)
b=ggplot(data2,aes(x=pred_occ_NM,y=obs_occ))+geom_point(aes(color="NONMEM Predicted"),size=2)+
  geom_abline(slope=1,intercept = 0)+scale_y_continuous(limits=c(0,100))+scale_x_continuous(limits=c(0,100))+
  geom_point(aes(x=pred_occ,color="App Predicted"),size=2)+
  labs(colour=NULL,title="Risperidone + OH", y = "Observed Occupancy (%)", x="Predicted Occupancy (%)")
print(b)

cor(data2$obs_tot,data2$tot)
cor(data2$obs_occ,data2$pred_occ)

write.csv(data2, "risp_pred_all_final.csv")


ggplot(data2,aes(x=CL))+
  geom_density(color="blue",aes(y=..density..),binwidth=10)+
  stat_function(fun = dlnorm,args=list(meanlog=log(13.7),sd=.59), colour = "red")+
  stat_function(fun = dlnorm,args=list(meanlog=log(77.7),sd=.52), colour = "red")+
  stat_function(fun = dlnorm,args=list(meanlog=log(158),sd=.52), colour = "red")+
  scale_x_continuous(limits=c(0,100))


ggplot(data2,aes(x=CLM))+geom_density(color="blue",aes(y=..density..),binwidth=1.5)+
  stat_function(fun = dlnorm,args=list(meanlog=log(8.83),sd=.547), colour = "red")

ggplot(data2,aes(x=CLM))+geom_histogram(color="blue",aes(y=..density..),binwidth=1.7)+
  stat_function(fun = dlnorm,args=list(meanlog=log(8.83),sd=.547), colour = "red")

ggplot(data2,aes(x=V))+geom_histogram(color="blue",aes(y=..density..),binwidth = 50)+
  stat_function(fun = dlnorm,args=list(meanlog=log(444),sd=.735/5), colour = "red")


qplot(obs_tot,obs_occ, data=data2)+geom_line(data=data2,aes(x=tot, y=88*tot/(tot+8.2)))



# 
# 
# pdf("risperidone_app_performance.pdf")
# a
# b
# dev.off()



data2$C_difference <- -data2$pred_conc+data2$obs_conc
data2$RSE <- sqrt(data2$C_difference^2)

mu <- mean(data2$C_difference)
#3.72

sigma <- sd(data2$C_difference)

mu+sigma*1.96/sqrt(length(data2$ID))
#-2.41 = 9.87

mu2 <- mean(data2$RSE)
#10.8166
sigma2 <- sd(data2$RSE)


mu2-sigma2*1.96/sqrt(length(data2$ID))
#6.71 - 14.93


data2$RO_difference <- -data2$pred_occ+data2$obs_occ
data2$RSE <- sqrt(data2$RO_difference^2)

mu <- mean(data2$RO_difference)
print(mu)
sigma <- sd(data2$RO_difference)
print(sigma)

mu-sigma*1.96/sqrt(length(data2$ID))
# -4.647022 - 1.687357

mu2 <- mean(data2$RSE)
# 5.804215
sigma2 <- sd(data2$RSE)
sigma2 

mu2-sigma2*1.96/sqrt(length(data2$ID))
#3.890496 - 7.717934

