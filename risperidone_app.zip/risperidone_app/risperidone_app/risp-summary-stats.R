# Setting working directory -----------------------------------------------

if(Sys.info()['sysname']=="Linux"){
  setwd("/media/mhismail/TI10657300D/Users/Mohamed/Desktop/Rprogramming/RispSim_v2")
}else{
  setwd("C:/Users/Mohamed/Desktop/Rprogramming/RispSim_v2")
}

risp_pred_all <- read.csv("risp_pred_all_final.csv")
