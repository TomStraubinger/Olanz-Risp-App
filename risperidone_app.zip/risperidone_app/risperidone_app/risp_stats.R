library(dplyr)
library(tidyr)

setwd("C:/Users/tas10/Box/Bies Lab/olanz_ris/Olanz-Risp App 10-2-2020/risperidone_app/risperidone_app")

risp_data <- read.csv("risp_pred_all_final.csv")

risp_C <- risp_data %>%
  select(ID, obs_tot, tot)
risp_OCC <- risp_data %>%
  select(ID, obs_occ, pred_occ)

risp_C$difference <- risp_C$obs_tot - risp_C$tot
risp_OCC$difference <- risp_OCC$obs_occ - risp_OCC$pred_occ

risp_C$RSE <- sqrt(risp_C$difference^2)
risp_OCC$RSE <- sqrt(risp_OCC$difference^2)


# Using 1.96 instead of qnorm(0.975) because 1.96 was used in the calculations for olanzapine
# Concenentration mean error
risp_C_mean <- mean(risp_C$difference)
risp_C_sd <- sd(risp_C$difference)

risp_C_95_upper <- risp_C_mean + risp_C_sd*1.96/sqrt(length(risp_C$ID))
risp_C_95_lower <- risp_C_mean - risp_C_sd*1.96/sqrt(length(risp_C$ID))

# Concentration RSE
risp_C_RSE_mean <- mean(risp_C$RSE)
risp_C_RSE_sd <- sd(risp_C$RSE)

risp_C_RSE_upper <- risp_C_RSE_mean + risp_C_RSE_sd*1.96/sqrt(length(risp_C$ID))
risp_C_RSE_lower <- risp_C_RSE_mean - risp_C_RSE_sd*1.96/sqrt(length(risp_C$ID))

# Occupancy mean error
risp_OCC_mean <- mean(risp_OCC$difference)
risp_OCC_sd <- sd(risp_OCC$difference)

risp_OCC_95_upper <- risp_OCC_mean + risp_OCC_sd*1.96/sqrt(length(risp_OCC$ID))
risp_OCC_95_lower <- risp_OCC_mean - risp_OCC_sd*1.96/sqrt(length(risp_OCC$ID))

# Occupancy RSE
risp_OCC_RSE_mean <- mean(risp_OCC$RSE)
risp_OCC_RSE_sd <- sd(risp_OCC$RSE)

risp_OCC_RSE_upper <- risp_OCC_RSE_mean + risp_OCC_RSE_sd*1.96/sqrt(length(risp_OCC$ID))
risp_OCC_RSE_lower <- risp_OCC_RSE_mean - risp_OCC_RSE_sd*1.96/sqrt(length(risp_OCC$ID))

# Summary table
risp_summary <- data.frame(
  Drug = rep("Risperidone",4),
  Parameter = c(rep("Concentration", 2), rep("Occupancy", 2)),
  Error_Type = rep(c("Mean Error", "Root Mean Squared Error"),2),
  Mean = c(risp_C_mean, risp_C_RSE_mean, risp_OCC_mean, risp_OCC_RSE_mean),
  SD = c(risp_C_sd, risp_C_RSE_sd, risp_OCC_sd, risp_OCC_RSE_sd),
  Lower_95_CI = c(risp_C_95_lower, risp_C_RSE_lower, risp_OCC_95_lower, risp_OCC_RSE_lower),
  Upper_95_CI = c(risp_C_95_upper, risp_C_RSE_upper, risp_OCC_95_upper, risp_OCC_RSE_upper)
)

risp_summary %>% View()



risp_raw <- read.csv("PPK_RIS_RAW.csv")
risp.df1 <- risp_raw %>% select(ID, TIME, AMT, MDV, DV, CMT) %>%
  filter(DV != "")
#risp.df1[risp.df1 == "."] <- NA
risp.df1$CMT[risp.df1$CMT == 1] <- "dose"
risp.df1$CMT[risp.df1$CMT == 2] <- "risp"
risp.df1$CMT[risp.df1$CMT == 3] <- "met"

risp.df2 <- risp.df1 %>% pivot_wider(names_from = CMT, values_from = DV, values_fill = list(".")) %>%
  select(-dose) %>%
  mutate(AMT = as.numeric(AMT)/1000,
         risp = as.numeric(risp),
         met = as.numeric(met))

risp_Emax = 0.88
risp_EC50 = 8.2

risp.df2 <- risp.df2 %>% mutate(comb = risp + met) %>%
  mutate(occ = (risp_Emax*comb)/(risp_EC50+comb)*100)

risp_stats <- risp.df2 %>% summarize(dose_mean = mean(AMT, na.rm=TRUE),
                                     dose_sd = sd(AMT, na.rm=TRUE),
                                     risp_mean = mean(risp, na.rm=TRUE),
                                     risp_sd = sd(risp, na.rm=TRUE),
                                     met_mean = mean(met, na.rm=TRUE),
                                     met_sd = sd(met, na.rm=TRUE),
                                     comb_mean = mean(comb, na.rm=TRUE),
                                     comb_sd = sd(comb, na.rm=TRUE),
                                     occ_mean = mean(occ, na.rm=TRUE),
                                     occ_sd = sd(occ, na.rm=TRUE))
View(risp_stats)




