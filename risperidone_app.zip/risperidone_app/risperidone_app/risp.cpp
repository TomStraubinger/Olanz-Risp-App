$PROB
Risperidone PK model
1 cmt oral abs w/ metabolite
mixture distribution on CL

$PARAM 
THETA1= 13.7//12.9 //CL in PM13.7// 
THETA2 = 158//65.4 // CL in EM158//
THETA3 = 77.7//36 // CL in IM77.7//
THETA4= 444 // V, Vm
THETA5 = 1.7 // ka
THETA6 = 8.83 // CLM
THETA7 = -0.378 // Age on CL
THETA8 = 0.96//1//0.96 // Fraction metabolized to paliper in PM
THETA9 = 0.595//1//0.595 // Fraction metabolized to paliper in EM
THETA10 = 1 // Fraction metabolized to paliper in IM
AGE = 50
PM_T = 1
IM_T = 0
EM_T = 0

ETA1 = 0
ETA2 = 0
ETA3 = 0
Emax = 88
EC50 = 8.2


$CMT Xgut Xp Xm

$MAIN

double TVKA = THETA5;
double KA = TVKA ;

double TVCL = THETA1*PM_T+THETA2*EM_T+THETA3*IM_T;
double CL = TVCL*exp(ETA1);

double TVCLM = THETA6 * exp(THETA7 * (AGE/50));
double CLM = TVCLM* exp(ETA3);

double TVV = THETA4;
double V = TVV * exp(ETA2);

double KF = THETA8 * PM_T + THETA9 * EM_T + THETA10 * IM_T;
double K20 = CL*(1-KF)/V;
double K23 = CL * KF/V;
double K30 = CLM/V;


$ODE

dxdt_Xgut = -KA*Xgut;
dxdt_Xp = KA*Xgut - K20*Xp - K23*Xp;
dxdt_Xm = K23*Xp-K30 * Xm;

$TABLE
double Cp = Xp/V;
double Cm = Xm/V;
double Ctot = Cp +Cm;
double occ = (Emax*Ctot/(EC50+Ctot));

$CAPTURE Cp Cm Ctot ETA1 ETA2 ETA3 occ CL CLM V

