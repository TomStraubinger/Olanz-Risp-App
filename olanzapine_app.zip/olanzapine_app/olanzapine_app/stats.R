
library(dplyr)

data1 <- read.csv("C:/Users/tas10/Box/Bies Lab/olanz_ris/Olanz-Risp App 10-2-2020/olanzapine_app/olanzapine_app/finaldataset2.csv",stringsAsFactors = FALSE)
data1$event<-rep(c("F","S"), nrow(data1)/2)
data1$TIME<-strptime(paste(as.Date(data1$DATE,format='%m/%d/%Y'),data1$TIME), '%Y-%m-%d %H:%M')
data1 <- data1 [-c(2,5,7,8,9,13,14,15,17,18,19,20)]
vv<-cbind (data1 [data1$event=='F',] [2],data1 [data1$event=='S',] [2])
colnames(vv)[2]<-'TIME2'
timediff<-(vv$TIME2-vv$TIME)/60
data1$TIMEDIFF<- as.vector(rbind(0,timediff))
data1$AMT<-c(NA,data1$AMT[-3054])
data1$II<-ifelse(data1$II=='.',0,data1$II)
data1$II<-c(NA,as.numeric(data1$II[-3054]))
data1<-data1[data1$event=='S',] [c(-2,-9)]
colnames (data1) [c(3,8)] <- c('conc','TIME')
data1$conc<-as.numeric(data1$conc)
data1$X.ID<- as.character(data1$X.ID)
data1$AMT<-as.numeric(data1$AMT)/1000

olz_EC50 = 10.4
olz_Emax = 1

data2 <- data1 %>%
  rename(SMOKE = J, MALE = E, AFR = M) %>%
  mutate(occ = (olz_Emax*conc)/(olz_EC50+conc)*100)
  

#num_dose_levels <- data2 %>% group_by(X.ID) %>% summarize(unique(AMT)) %>% count(X.ID)

num_dose_levels <- data2 %>% group_by(X.ID) %>% summarize(AMT = unique(AMT)) %>% mutate(dose_seq = seq_along(AMT))

data3 <- left_join(data2, num_dose_levels)

olz_stats <- data2 %>% summarize(dose_mean = mean(AMT),
                                 dose_sd = sd(AMT),
                                 conc_mean = mean(conc),
                                 conc_sd = sd(conc),
                                 occ_mean = mean(occ),
                                 occ_sd = sd(occ))
View(olz_stats)
