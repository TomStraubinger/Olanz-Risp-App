library(ggplot2)
library(mrgsolve)
library(minqa)
library(dplyr)
library(magrittr)
library(reshape2)
library(tidyr)


# Setting theme of plots --------------------------------------------------

theme_set(theme_bw())
theme_update(legend.position = "bottom",
             plot.title = element_text(hjust = 0.5))


# Setting working directory -----------------------------------------------

if(Sys.info()['sysname']=="Linux"){
  setwd("/media/mhismail/TI10657300D/Users/Mohamed/Desktop/Rprogramming/OlanzSim_v3")
}else{
  setwd("C:/Users/Mohamed/Desktop/Rprogramming/OlanzSim_v3")
}


# Read in and clean raw data ----------------------------------------------

raw <- read.csv("PPK_OLZ.csv",as.is=T)
raw <- mutate (raw, datetime= paste(DATE,TIME) )
raw$datatime <- as.POSIXct(raw$datetime,format="%m/%d/%Y %T")
raw1 <- group_by(raw,ID)%>% mutate (.,TSFD = datatime-datatime[1] )%>%ungroup()
raw1$TIME <- as.numeric(raw1$TSFD/60/60)
raw1$AMT <- as.numeric(raw1$AMT)/1000
raw1$SS <- as.numeric(raw1$SS)
raw1<- rename(raw1, SMOKE=SMOK,BLACK=AA)

raw1<- select (raw1, ID:BLACK,-RATE)
raw1$EVID=1

#View raw data
head(raw1)
# write.csv(raw1,"final_dosing.csv",row.names = F)
#Create empy dataframe
pred = data.frame(ID=NULL,OLZ=NULL,OCC=NULL)


# Set olanzapine model ----------------------------------------------------

# Model based on Bigos et. al.---------------------------------------------


mod <- mread ("olanz")

#Omega values from final estimates (CL,corr_CL_V, V)
omega <- cmat(0.212,0, 0.528)
sigma2 <- matrix(212) #RUV

#Intial Estimates for etas
init = c(0,0)

time.df = data.frame()


#Define mapbayes objective function
mapbayes <- function(eta,omega,sigma2,obs,data,mod) {
  
  sig2 <- as.numeric(sigma2)
  names(eta) <- names(init)
  eta_m <- eta %>% unlist %>% matrix(nrow=1)
  omega.inv <- solve(omega)
  
  out <- mod %>%
    drop.re() %>%
    data_set(data) %>%
    param(eta)%>%
    obsonly%>%
    mrgsim(end=-1, add = time)
  out <- filter(out, TIME %in% time)
  sig2j <- sig2
  sqwres <- log(sig2j) + (1/sig2j)*(obs-out$Cp)^2
  nOn <- as.numeric(eta_m %*% omega.inv %*% t(eta_m))
  
  
  vals <<- rbind(vals,c(eta[1],eta[2]))
  return(sum(sqwres) + nOn)
}

data1<- read.csv("raw_olz.csv",as.is = T)


# Optimize parameters for each subject
for (i in 1:length(unique(raw1$ID))){  
  
start.time <- Sys.time()

IDi=as.numeric(unique(raw1$ID)[i])


IDi_df <- filter(raw1,ID==IDi)
obstime <- IDi_df$TIME[length(IDi_df$TIME)]



data = filter(IDi_df,MDV==1)
eta=init
m=mod
d=data
y=IDi_df$DV[!is.na(IDi_df$DV)]
time = IDi_df$TIME[!is.na(IDi_df$DV)]





vals=data.frame(ETA1=NULL,ETA2=NULL)
init <- c(ETA1=0.001, ETA2=0.001)
fit<-optim(init,mapbayes,method="BFGS", obs=y,omega=omega,sigma2=sigma2, data= data, mod = mod)
fit$par
mod
out <- mod %>%
  param(list(ETA1=fit$par[1],ETA2=fit$par[2]))%>%
  zero.re()%>%
 data_set(data) %>% 
  mrgsim(end=obstime,delta=1,add=c(time,obstime))
conc <- as.data.frame(out)%>% rename (conc = Cp)

Emax = 90.7
EC50 = 10.4
occupancy<- (Emax*conc$conc[conc$TIME==obstime])/(EC50+conc$conc[conc$TIME==obstime])

pred <- rbind(pred, data.frame(ID=IDi,pred_conc=conc$conc[conc$TIME==obstime],pred_occ=occupancy,
                               CL=conc$CL[conc$TIME==obstime],V=conc$V[conc$TIME==obstime]))
print(c(IDi,conc$conc[conc$TIME==obstime]))

obs<- filter(data1,ID==IDi)

print(ggplot(filter(conc,conc!=0), aes(x =TIME, y= conc,color="IPRED" ))+geom_line()+geom_line(aes(y=Cp_pop,color="POPPRED"))+
        geom_point(data=obs,aes(x=obstime,y=obs_conc))+geom_point(data=data.frame(time,y),aes(x=time,y=y))+
        labs(title=IDi))

end.time <- Sys.time()
time.taken <- end.time - start.time
time.df <- rbind(time.df,data.frame(ID=IDi, time.taken))
  

} 




# Compare to NONMEM and raw data ------------------------------------------
data2<- merge(data1,pred)
olanz = data2



a=ggplot(data2,aes(x=pred_conc_NM,y=obs_conc))+geom_point(aes(color="NONMEM Predicted"))+
  geom_abline(slope=1,intercept = 0)+scale_y_continuous(limits=c(0,180))+scale_x_continuous(limits=c(0,180))+
  geom_point(aes(x=pred_conc,color="App Predicted"))+geom_text(aes(label=ID),nudge_y=5,size=3)+
  labs(colour=NULL,title="Olanzapine", y = "Observed Olanzapine (mcg/L)", x="Predicted Occupancy (mcg/L)")
print(a)

b=ggplot(data2, aes(x=pred_occ,y=obs_occ))+geom_point()+
  geom_abline(slope=1,intercept = 0)+scale_y_continuous(limits=c(0,100))+scale_x_continuous(limits=c(0,100))+
  labs(colour=NULL,title="Olanzapine", y = "Observed Occupancy (%)", x="Predicted Occupancy (%)")
print(b)



# write.csv(data2, "olanz_pred_all.csv")


cor(data2$obs_conc,data2$pred_conc,method = "pearson")
cor(data2$obs_conc,data2$pred_conc_NM,method = "pearson")

cor(data2$obs_occ,data2$pred_occ)
cor(data2$obs_occ,data2$pred_occ_NM)


mean(time.df$time.taken)




# Plot ditributions -------------------------------------------------------


ggplot(data2,aes(x=CL))+geom_histogram(color="blue",aes(y=..density..),binwidth=6)+
  stat_function(fun = dlnorm,args=list(meanlog=log(16.2),sd=.46), colour = "red")+
  scale_x_continuous(limits = c(0.01, 40))

ggplot(data2,aes(x=CL))+geom_density(color="blue",aes(y=..density..),binwidth=6)+
  stat_function(fun = dlnorm,args=list(meanlog=log(16.2),sd=.46), colour = "red")+
  scale_x_continuous(limits = c(0.01, 40))







data2$C_difference <- -data2$pred_conc+data2$obs_conc
data2$RSE <- sqrt(data2$C_difference^2)

mu <- mean(data2$C_difference)
#3.72

sigma <- sd(data2$C_difference)

mu+sigma*1.96/sqrt(length(data2$ID))
#-2.41 = 9.87

mu2 <- mean(data2$RSE)
#10.8166
sigma2 <- sd(data2$RSE)


mu2-sigma2*1.96/sqrt(length(data2$ID))
#6.71 - 14.93


data2$RO_difference <- -data2$pred_occ+data2$obs_occ
data2$RSE <- sqrt(data2$RO_difference^2)

mu <- mean(data2$RO_difference)
print(mu)
sigma <- sd(data2$RO_difference)
print(sigma)

mu-sigma*1.96/sqrt(length(data2$ID))
# -4.647022 - 1.687357

mu2 <- mean(data2$RSE)
# 5.804215
sigma2 <- sd(data2$RSE)
sigma2 

mu2-sigma2*1.96/sqrt(length(data2$ID))
#3.890496 - 7.717934