library(ggplot2)
library(mrgsolve)
library(minqa)
library(dplyr)
library(magrittr)

mod <- mread ("olanz")
SS=1
dose = 25

omega <- cmat(0.212,-0.2, 0.528)
omega.inv <- solve(omega)
sigma <- matrix(20)

time = c(18)
conc =c( 5)
init = c(0,0)

data = ev(ID=1, amt = 25, time = 0, cmt =1 )
eta=init
m=mod
d=data
y=conc

mapbayes <- function(eta,y,d,m,pred=FALSE) {
  
  sig2 <- as.numeric(sigma)
  eta %<>% as.list
  names(eta) <- names(init)
  eta_m <- eta %>% unlist %>% matrix(nrow=1)
  m %<>% param(eta)
  if(!pred) m %<>% obsonly
  out <- m %>% drop.re() %>% data_set(d) %>% mrgsim(end=-1, add = time)
  sig2j <- sig2
  sqwres <- log(sig2j) + (1/sig2j)*(y-out$Cp)^2
  nOn <- as.numeric(eta_m %*% omega.inv %*% t(eta_m))
  return(sum(sqwres) + nOn)
  
}

init <- c(ETA1=10, ETA2=-1)
fit<-newuoa(init,mapbayes, y=conc, d= data, m = mod)
fit$par
mod
out <- mod %>%
  param(SMOKE= 0,
        SEX = 0,
        BLACK = 0,
        list(ETA1=fit$par[1],ETA2=fit$par[2]))%>%
  zero.re()%>%
 data_set(data) %>% 
  mrgsim(end=-1,add=time)
conc <- as.data.frame(out)%>% rename (conc = Cp, TIME =time)
