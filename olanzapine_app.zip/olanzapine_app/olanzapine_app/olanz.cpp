$PROB
Olanz PK model
1 cmt oral abs

$PARAM THETA1= 16.2, THETA2 = 2230, THETA3 = 0.5, THETA4= 8.74
THETA5 = 5.14, THETA6 = 4.28, SMOKE = 0, SEX= 0, BLACK=0
ETA1 = 0, ETA2 = 0

$CMT Xgut Xp Xp_pop

$MAIN

double TVCL = THETA1+SMOKE*THETA4+SEX*THETA5+BLACK*THETA6;
double CL = TVCL*exp(ETA1);
double TVV = THETA2;
double V = TVV * exp(ETA2);
double TVKA = THETA3;
double KA = TVKA;

double KE = CL/V;
double TVKE = TVCL/TVV;


$ODE

dxdt_Xgut = -KA*Xgut;
dxdt_Xp = KA*Xgut - KE*Xp;


dxdt_Xp_pop = KA*Xgut - TVKE*Xp_pop;

$TABLE
double Cp = Xp*1000/V;
double Cp_pop = Xp_pop*1000/TVV;

$CAPTURE Cp ETA1 ETA2 KA KE CL V Cp_pop

