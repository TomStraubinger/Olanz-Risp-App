library(DT)
library(plotly)


data1 <- read.csv("C:/Users/tas10/Box/Bies Lab/olanz_ris/Olanz-Risp App 10-2-2020/olanzapine_app/olanzapine_app/finaldataset2.csv",stringsAsFactors = FALSE)
data1$event<-rep(c("F","S"), nrow(data1)/2)
data1$TIME<-strptime(paste(as.Date(data1$DATE,format='%m/%d/%Y'),data1$TIME), '%Y-%m-%d %H:%M')
data1 <- data1 [-c(2,5,7,8,9,13,14,15,17,18,19,20)]
vv<-cbind (data1 [data1$event=='F',] [2],data1 [data1$event=='S',] [2])
colnames(vv)[2]<-'TIME2'
timediff<-(vv$TIME2-vv$TIME)/60
data1$TIMEDIFF<- as.vector(rbind(0,timediff))
data1$AMT<-c(NA,data1$AMT[-3054])
data1$II<-ifelse(data1$II=='.',0,data1$II)
data1$II<-c(NA,as.numeric(data1$II[-3054]))
data1<-data1[data1$event=='S',] [c(-2,-9)]
colnames (data1) [c(3,8)] <- c('conc','TIME')
data1$conc<-as.numeric(data1$conc)
data1$X.ID<- as.character(data1$X.ID)
data1$AMT<-as.numeric(data1$AMT)/1000


shinyUI(
  navbarPage("TDMPath",position = "fixed-top",
  tabPanel("Initial Dosing", fluidPage(
  tags$style(type="text/css", "body {padding-top: 50px; padding-left:40px;}"),
  titlePanel("Optimize Olanzapine"),
  column(3,
           fluidRow(
      conditionalPanel( condition="input.data== false",selectInput ("par_est",
                   label = "Simulate for Specific Dose or Target Specific Trough",
                   choices= c("Dose", 
                              "Trough (SS)",
                              "Receptor Occupancy at Trough (SS)"),
                   selected = "Dose")),
      conditionalPanel(
        condition="input.par_est == 'Dose'& input.data== false" ,numericInput("dose",
                                                          label = "Dose (mg)",
                                                          value= 25)),
      conditionalPanel(
        condition="input.par_est == 'Trough (SS)'& input.data== false ",numericInput("trough",
                                                                   label = "Trough (ug/L)",
                                                                   value= 26)),
      conditionalPanel(
        condition="input.par_est ==  'Receptor Occupancy at Trough (SS)' & input.data== false ",numericInput("r_occ",
                                                                                     label = "Receptor Occupancy (%)",
                                                                                     value= 80)),
      
      conditionalPanel( condition="input.data== false",numericInput ('interval', 'Enter dosing interval in hours', value = 24)),
      conditionalPanel( condition="input.data== false",numericInput('n', 'Enter Number of Doses', value= 5)),
      
      conditionalPanel(condition="input.data == false ",checkboxInput('SMOKE', 'Smoker?', value = FALSE)),
      conditionalPanel(condition="input.data == false ",checkboxInput('MALE', 'Male?', value = FALSE)),
      conditionalPanel(condition="input.data == false ",checkboxInput('AFR', 'African?', value = FALSE)),
      checkboxInput('SS', 'View Steady State Profile', value = FALSE),
      checkboxInput('data', 'Include CATIE study subjects', value = FALSE),
      conditionalPanel(
        condition="input.data == true ",selectInput ("ID",
                                               label = "Select Subject ID",
                                               choices= data1$X.ID, selected ='1007')),
      
      uiOutput('ID_dose')
      
      
    )),
  
    column(9,
      column(12,tabsetPanel(type="tabs",
                            tabPanel("PK Profile", plotOutput("plot1",height="auto")),
                            tabPanel("Receptor Occupancy",plotOutput("plot3",height="auto")),
                            tabPanel ("Parameters",column(4,dataTableOutput('table1')) )
       ))#,
      # column(4,offset=2,dataTableOutput('table1'))
      
      
    ))),
  tabPanel("Adaptive Dosing", fluidPage(#theme = "bootstrap.css",
    
    titlePanel("Optimize Olanzapine"),
    
    column(4,wellPanel(fluidRow(
      tabsetPanel(type="tabs",
        tabPanel("Observed",
                 
        checkboxGroupInput("cov","Patient Characteristics",choices=c("Smoker?","Male?", "African?"),inline=T), 
                 
        radioButtons("SS_adapt",
                     label = "Concentration/s taken at:",
                     choices= c("Single Dose", "Steady State"),
                     inline=T),   
        
        radioButtons("n_obs",
                     label = "Number of observations:",
                     choices= c("1", "2"),
                     inline=T), 
        
        
        numericInput("dose2",
                       label = "Dose Adminstered (mg)",
                       value= 25),
        
        
        
        conditionalPanel(
          condition="input.SS_adapt == 'Steady State' ",numericInput("intervaladapt",
                                                                     label = "Dosing Interval (hrs.)",
                                                                     value= 24)),
        # column(12, 
               
               h4("Observation 1",align="center", style = "color:red"),
              fluidRow(column(5, 
        numericInput("timeafterdose",
                     label = "Enter time after dose (hrs)",
                     value= 12)),
        
        column(7,
               numericInput("Concentration",
                            label = "Enter observed concentration (mcg/L)",
                            value= 10))),
        
        fluidRow(conditionalPanel(
          condition="input.n_obs == '2' ",
               h4("Observation 2",align="center", style = "color:red"), 
               column(5, 
                      numericInput("timeafterdose2",
                                   label = "Enter time after dose (hrs)",
                                   value= 10)), 
               
               column(7,
                      numericInput("Concentration2",
                                   label = "Enter observed concentration (mcg/L)",
                                   value= 12))))
        
      

        
       
        
       
      ),
      tabPanel("Simulate New Regimen",
               numericInput ('interval2', 'Enter dosing interval in hours', value = 24),
               numericInput('n2', 'Enter Number of Doses', value= 5),
               
               
               selectInput ("par_est1",
                            label = "Simulate for Specific Dose or Target Specific Trough",
                            choices= c("Dose", 
                                       "Trough (SS)",
                                       "Receptor Occupancy at Trough (SS)"),
                            selected = "Dose"),
               conditionalPanel(
                 condition="input.par_est1 == 'Dose' ",numericInput("doseadapt",
                                                                    label = "Dose (mg)",
                                                                    value= 50)),
               conditionalPanel(
                 condition="input.par_est1 == 'Trough (SS)' ",numericInput("troughadapt",
                                                                           label = "Trough (ug/L)",
                                                                           value= 26)),
               conditionalPanel(
                 condition="input.par_est1 ==  'Receptor Occupancy at Trough (SS)' & input.data== false ",numericInput("r_occ1",
                                                                                                                       label = "Receptor Occupancy (%)",
                                                                                                                       value= 80)))),
      column(8,checkboxInput('SS2', 'View Steady State Profile', value = FALSE)),
      column(4,actionButton("goButton", "Go!"))))),
      column(8,
             column(12, tabsetPanel(type = "tabs",
                                    tabPanel("PK Profile",plotlyOutput("plot2", height="auto")),
                                    tabPanel("Receptor Occupancy", plotlyOutput("plot4", height="auto") ),
                                    tabPanel("Parameters",column(4,dataTableOutput('table2') )
                                    ))
                )
        
      
      ))))
)