#Load Libraries
library(shiny)
library(ggplot2)
#library(deSolve)
library(plyr)
library(reshape2)
library(grid)
library(dplyr)
library(magrittr)
library(tidyr)
library(LambertW)
library(DT)
library(mrgsolve)
library(minqa)
library(plotly)





## GGplot Options
theme_set(theme_bw())
theme_update(
  axis.title.x = element_text(face="bold", size=20, margin=margin(20,0,0,0)),
  axis.title.y = element_text(face="bold",angle=90, size=20, margin=margin(0,20,0,0)),
  axis.text.x = element_text(size=15),
  axis.text.y = element_text(size=15),
  legend.direction="vertical",
  legend.position="right",
  legend.key = element_blank(),
  legend.key.height=unit(3,"line"),
  legend.text =  element_text(size=14),
  legend.title = element_text(size=15,vjust=1),
  plot.title = element_text(face="bold",size=26, vjust = 1.6)

)



#Read in model > 
mod<-mread("olanz")


shinyServer(
  
  function(input, output, session) {
    # Close app when browser window is closed
    session$onSessionEnded(function(){
      stopApp()
    })
    
    ### Create a UI element when a condition is met###
    ### When user indaicates they would like to plot data from CATIE study, show "Select Dose" input
    # output$ID_dose <- renderUI({
    #   
    #   conditionalPanel(
    #     condition="input.data == true ",selectInput ("ID_dose",
    #                                                  label = "Select Dose",
    #                                                  choices= data1$AMT[data1$X.ID==input$ID]))
    # })
    
    ##### Initial Dosing############    
    output1 <- reactive ({
      
    ### Subsetting CATIE data for specific patient and dose 
    
    # datasub<- data1[data1$X.ID== input$ID & data1$AMT== as.numeric(input$ID_dose),]
    # datasub$II<- datasub$II
    

    
    ### Covariates
    SMOKE <-  as.numeric(input$SMOKE)
    MALE <- as.numeric(input$MALE)
    AFR <- as.numeric(input$AFR)
    
    # #### Population Mean PK parameters
    CL= 16.2+8.74*SMOKE+5.13*MALE+4.28*AFR #L/hr
    KA=0.5  #hr^-1
    V =2230 #L

    ke <- CL/V #hr^-1
    
    # Input number of doses & interval
    n=input$n
    interval = input$interval#hr
    Emax = 1
    EC50 = 10.4
    
    # User inputs trough if they would like to target a specific trough
    Cmin <- if (input$par_est == "Trough (SS)") input$trough else
            if (input$par_est == "Receptor Occupancy at Trough (SS)") input$r_occ/100*EC50/Emax/(1-input$r_occ/100/Emax)
    
    
    # if user would like to simulate for specific dose, input dose
    # if user would like to target specific trough, dose is calculated
    # if user would like to view CATIE subject, dose is obtained from CATIE data
    dose <- if(input$par_est== "Dose" && input$data ==FALSE )  input$dose else
      if (input$par_est == "Trough (SS)" && input$data ==FALSE) 1/1000*Cmin * V * (KA * exp(-ke * interval) * exp(-KA * interval) - exp(-ke * interval) * exp(-KA * interval) * ke - KA * exp(-ke * interval) - KA * exp(-KA * interval) + ke * exp(-ke * interval) + exp(-KA * interval) * ke + KA - ke) / KA / (exp(-ke * interval) - exp(-KA * interval)) else
      if (input$par_est == "Receptor Occupancy at Trough (SS)" && input$data ==FALSE) 1/1000*Cmin * V * (KA * exp(-ke * interval) * exp(-KA * interval) - exp(-ke * interval) * exp(-KA * interval) * ke - KA * exp(-ke * interval) - KA * exp(-KA * interval) + ke * exp(-ke * interval) + exp(-KA * interval) * ke + KA - ke) / KA / (exp(-ke * interval) - exp(-KA * interval)) else
      if (input$data == TRUE) as.numeric(input$ID_dose)

    
    # #If user would like to see SS profile, SS is calculated
    # conc$concSS <- if (input$SS==FALSE) NULL else 1000*dose*KA*(exp(-ke*TIME)/(1-exp(-ke*interval))-exp(-KA*TIME)/(1-exp(-KA*interval)))/V/(KA-ke)
    SS= input$SS

    out <- mod %>%
      param(SMOKE= SMOKE,
            SEX = MALE,
            BLACK = AFR)%>%
       ev(cmt = 1,amt = dose, ii=interval,ss=as.numeric(SS), addl = n-1)%>% 
      mrgsim(end=interval*n, delta = .5)
    conc <- as.data.frame(out)%>% dplyr::rename(conc = Cp, TIME =time)
    
    if (SS==T) conc = conc[-1,] 

    conc$occupancy<- (Emax*conc$conc)/(EC50+conc$conc)
    
    KA <- conc$KA[1]
    ke <- conc$KE[1]
    V <- conc$V[1]
    CL <- conc$CL[1]
    
    
  
    #calculate tmax
    tmaxSS <- log(KA/ke*(1-exp(-ke*interval))/(1-exp(-KA*interval)))/(KA-ke)
    
    #calculate peak
    CmaxSS <- 1000*dose*KA*(exp(-ke*tmaxSS)/(1-exp(-ke*interval))-exp(-KA*tmaxSS)/(1-exp(-KA*interval)))/V/(KA-ke)
    
    # Calculate trough
    CminSS <-1000*dose*KA*(exp(-ke*interval)/(1-exp(-ke*interval))-exp(-KA*interval)/(1-exp(-KA*interval)))/V/(KA-ke)
    occupancyminSS<- (Emax*CminSS)/(EC50+CminSS)*100
    
    
    Parameter <- c('Dose (mg)', "CL (L/hr)", "Vd (L)", "Trough (SS) (mcg/L)", "Receptor Occupancy at SS Trough (%)", 'ka (1/hr)', 'ke (1/hr)')
    Value <- c(dose, CL, V, CminSS,occupancyminSS, KA, ke)
    df<-data.frame(Parameter, Value=round(Value,2))
    #View(df)
    df<-datatable(df,options=list(paging=FALSE,searching=FALSE,ordering=FALSE,columns.width=2))
    
    
    conc$X.ID<-"Population Mean"
    
    #View(conc)
    
    legend<- if (input$data == TRUE) c(16,NA) else NA
    legend2<- if (input$data == TRUE) c(0,1) else 1
    
    # dataplot<-geom_point(data=datasub)
    # if (input$data==FALSE) {
    #   dataplot<-NULL
    # }
    
    plot1<-ggplot(conc, aes(x=TIME, y=conc, color=X.ID))+
      geom_line(size=1)+ylim(0,if (CmaxSS<50) 50 else CmaxSS+20)+
      labs(x="Time (hr)", y="Concentration (ug/L)")+
      xlim(0,(n+2)*interval)+
      guides(color=guide_legend(override.aes=list(shape=legend,linetype=legend2)))
    
    plot3<-ggplot(conc, aes(x=TIME, y=occupancy*100, color=X.ID))+
      geom_line(size=1)+ylim(0,100)+
      labs(x="Time (hr)", y="Receptor Occupancy (%)")+
     xlim(0,(n+2)*interval)
      
    output<-list(plot1,df,plot3)

    })
    
    output$plot1 <- renderPlot (height = 500, units="px",{
    list<-output1()
    list[[1]]
      }
    )
    
    output$plot3 <- renderPlot (height = 500, units="px",{
      list<-output1()
      list[[3]]
    }
    )
    
    output$table1 <- renderDataTable({
      list <- output1()
      list[[2]]
    })
    
######Adaptive Dosing##########
    
    
    output2 <- reactive ( {
      
      input$goButton
      
      KA<- 0.5  #hr^-1
      dose <-   isolate(input$dose2 )
      cov <- isolate(input$cov)
      
      omega <- cmat(0.212,0, 0.528)
      # omega <- cmat(100,0,100)
      omega.inv <- solve(omega)
      sigma <- matrix(212)
      interval = isolate(input$intervaladapt)
      
      SS=isolate(ifelse(input$SS_adapt=="Steady State",1,0))
      
      data = ev(ID=1, amt = dose, time = 0, cmt =1, ss=SS, ii= interval )
      init = c(ETA1=0.01,ETA2=0.01)
      # mod <- mod# %>% param(SMOKE= cov[1],
                 #          SEX = cov[2],
                  #         BLACK = cov[3])
      
      mapbayes <- function(eta,y,d,m,pred=FALSE) {
        
        sig2 <- as.numeric(sigma)
        eta %<>% as.list
        names(eta) <- names(init)
        eta_m <- eta %>% unlist %>% matrix(nrow=1)
        m %<>% param(eta,
                     SMOKE= as.numeric("Smoker?"%in%cov),
                     SEX = as.numeric("Male?"%in%cov),
                     BLACK = as.numeric("Black/African American?"%in%cov))
        if(!pred) m %<>% obsonly
        out <- m %>% zero_re() %>% data_set(d) %>% mrgsim(end=-1, add = t)
        sig2j <- sig2
        sqwres <- log(sig2j) + (1/sig2j)*(y*1000-out$Cp)^2
        nOn <- as.numeric(eta_m %*% omega.inv %*% t(eta_m))
        return(sum(sqwres) + nOn)
        
      }
      
      
      if (isolate(input$n_obs=="1")) { 
      t<- isolate(input$timeafterdose)
      Conc_measured <- isolate(input$Concentration/1000)
      Conc <-Conc_measured
      }
        
      if (isolate(input$n_obs=="2")){
       time1 <- isolate(input$timeafterdose)
       time2 <- isolate(input$timeafterdose2)
       conc1 <- isolate(input$Concentration/1000)
       conc2 <- isolate(input$Concentration2/1000)
       t=c(time1,time2)
       Conc=c(conc1,conc2)
      }
      
      fit<-newuoa(init,mapbayes, y=Conc, d= data, m = mod)
      #print(fit$par[1])
      
      SS<- as.numeric(input$SS2)
      
      out2 <- mod %>%
        param(SMOKE= as.numeric("Smoker?"%in%cov),
              SEX = as.numeric("Male?"%in%cov),
              BLACK = as.numeric("Black/African American?"%in%cov),
              ETA1=fit$par[1],
              ETA2=fit$par[2])%>%
        ev(amt=0)%>%
        mrgsim(end=0, delta = .5)
      conc2 <- as.data.frame(out2)%>% dplyr::rename(conc = Cp, TIME =time)
      
      
      CL <- conc2$CL[1]
      V <- conc2$V[2]
      
      
      ke <- CL/V #hr^-1
      
     
      
      n=input$n2
      interval2= input$interval2  #hr
      interval = input$intervaladapt
      Emax = 1
      EC50 = 10.4
      
      
      Cmin <- if (input$par_est1 == "Trough (SS)") input$troughadapt else
        if (input$par_est1 == "Receptor Occupancy at Trough (SS)") input$r_occ1/100*EC50/Emax/(1-input$r_occ1/100/Emax)
      
      
       dose2<-if(input$par_est1== "Dose"  )  input$doseadapt else
         if (input$par_est1 == "Receptor Occupancy at Trough (SS)") 1/1000*Cmin * V * (KA * exp(-ke * interval2) * exp(-KA * interval2) - exp(-ke * interval2) * exp(-KA * interval2) * ke - KA * exp(-ke * interval2) - KA * exp(-KA * interval2) + ke * exp(-ke * interval2) + exp(-KA * interval2) * ke + KA - ke) / KA / (exp(-ke * interval2) - exp(-KA * interval2)) else
        if (input$par_est1 == "Trough (SS)" ) 1/1000*Cmin * V * (KA * exp(-ke * interval2) * exp(-KA * interval2) - exp(-ke * interval2) * exp(-KA * interval2) * ke - KA * exp(-ke * interval2) - KA * exp(-KA * interval2) + ke * exp(-ke * interval2) + exp(-KA * interval2) * ke + KA - ke) / KA / (exp(-ke * interval2) - exp(-KA * interval2)) 
      
       
       SS<- as.numeric(input$SS2)
       SMOKE=0
       SEX=0
       AFR=0
       
       out <- mod %>%
         param(SMOKE= as.numeric("Smoker?"%in%cov),
               SEX = as.numeric("Male?"%in%cov),
               BLACK = as.numeric("Black/African American?"%in%cov),
               ETA1=fit$par[1],
               ETA2=fit$par[2])%>%
         data_set(expand.ev(ID=1,cmt = 1,amt = c(dose,dose2), ii=c(interval,interval2),ss=as.numeric(SS), addl = n-1)[c(1,4),])%>% 
         obsonly()%>%
         mrgsim(start = 0.005,end=interval*n, delta = .5)
       conc <- as.data.frame(out)%>% dplyr::rename(conc = Cp, TIME =time)
       
       outpopmean <- mod %>%
         param(SMOKE= as.numeric("Smoker?"%in%cov),
               SEX = as.numeric("Male?"%in%cov),
               BLACK = as.numeric("Black/African American?"%in%cov),
               ETA1=0,
               ETA2=0)%>%
         data_set(expand.ev(ID=1,cmt = 1,amt = c(dose,dose2), ii=c(interval,interval2),ss=as.numeric(SS), addl = n-1)[c(1,4),])%>% 
         mrgsim(start = 0.005,end=interval*n, delta = .5)
       concpopmean <- as.data.frame(outpopmean)%>% dplyr::rename(conc = Cp, TIME =time)
     
       conc$occupancy<- (Emax*conc$conc)/(EC50+conc$conc)
       
       KA <- conc$KA[1]
       ke <- conc$KE[1]
       V <- conc$V[1]
       CL <- conc$CL[1]
      

      tmaxSS <- log(KA/ke*(1-exp(-ke*interval))/(1-exp(-KA*interval)))/(KA-ke)
      
      CmaxSS <- 1000*dose*KA*(exp(-ke*tmaxSS)/(1-exp(-ke*interval))-exp(-KA*tmaxSS)/(1-exp(-KA*interval)))/V/(KA-ke)
      CmaxSSadapt <- 1000*dose2*KA*(exp(-ke*tmaxSS)/(1-exp(-ke*interval2))-exp(-KA*tmaxSS)/(1-exp(-KA*interval2)))/V/(KA-ke)
      
      conc2<- filter(conc, ID==4)
      conc <- filter(conc, ID==1)
      
      conc$X.ID<-"Original Dose"
      conc2$X.ID<-"Adjusted Dose"
      
      conc2popmean<- filter(concpopmean, ID==4)
      concpopmean <- filter(concpopmean, ID==1)
      
      concpopmean$X.ID<-"Original Dose (Population Mean)"
      conc2popmean$X.ID<-"Adjusted Dose (Population Mean)"
      
      
      #observed
      boogity <- data.frame(t=t, Conc=Conc)
 
      p<-ggplot(conc, aes(x=TIME, y=conc, color=X.ID))+geom_line(size=.7)+
        labs(x="Time (hr)")+geom_line(data=conc2,size=.7)+
        geom_line(data=conc2popmean,size=.7,linetype=2)+geom_line(data=concpopmean,size=.7,linetype=2)+
        geom_point(data=boogity,aes(x=t, y=1000*Conc, color="Observed Concentration"),size=2)+
        geom_blank(aes()) +
        guides(color=guide_legend(override.aes=list(shape=c(NA, NA, 16, NA, NA),linetype=c(1, 2, 0, 2, 1))))+
        scale_colour_manual(values = c(3, 3, 2, 4, 4))
        
      
      plot4<-ggplot(conc, aes(x=TIME, y=occupancy*100, color=X.ID))+
        geom_line(size=.7)+geom_line(data=conc2,size=.7)+
        labs(x="Time (hr)", y="Receptor Occupancy (%)")+
        xlim(0,(n+2)*interval)+
        scale_colour_manual(values = c(3,4))
      
      newdose<-dose2
      
      CminSS <-1000*dose*KA*(exp(-ke*interval)/(1-exp(-ke*interval))-exp(-KA*interval)/(1-exp(-KA*interval)))/V/(KA-ke)
      occupancyminSS<- (Emax*CminSS)/(EC50+CminSS)*100
      
      
       tmaxSS <- log(KA/ke*(1-exp(-ke*interval))/(1-exp(-KA*interval)))/(KA-ke)
      CmaxSS <- 1000*dose*KA*(exp(-ke*tmaxSS)/(1-exp(-ke*interval))-exp(-KA*tmaxSS)/(1-exp(-KA*interval)))/V/(KA-ke)
      
      CminSSadapt <-1000*newdose*KA*(exp(-ke*interval2)/(1-exp(-ke*interval2))-exp(-KA*interval2)/(1-exp(-KA*interval2)))/V/(KA-ke)
      occupancyminSSadapt<- (Emax*CminSSadapt)/(EC50+CminSSadapt)*100
        
      
      Parameter <- c('Dose (mg)', "CL (L/hr)", "Vd (L)", "Trough (SS) (mcg/L)","Receptor Occupancy at SS Trough (%)", 'ka (1/hr)', 'ke (1/hr)')
      Value <- c(dose, CL, V, CminSS,occupancyminSS, KA, ke)
      Value2<-c(newdose, CL, V, CminSSadapt,occupancyminSSadapt, KA, ke)
      df<-data.frame(Parameter, "Original Dose"=round(Value,digits=2),"New Dose"=round(Value2,digits=2))
      
      df<-datatable(df,options=list(paging=FALSE,searching=FALSE,ordering=FALSE,columns.width=2))
    
      
      
      list<- list(p,df, plot4)
     
        
    })
    
    output$plot2 <- renderPlotly ({
    list<-output2()
    ggplotly(list[[1]]) %>% layout(margin = list(l = -10),
                                   yaxis=list(title = list(text = sprintf("<b>Concentration (\u03BCg/L)</b>"), size = 20)))
    })
    
    output$plot4 <- renderPlotly ({
      list<-output2()
      ggplotly(list[[3]]) %>% layout(margin = list(l = -10))
    }
    )
    
    
    
    output$table2 <- renderDataTable({
      
      list<-output2()
      list[[2]]
      

    })
    
})
